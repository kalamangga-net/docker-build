#!/bin/bash
service apache2 start
service ssh start
